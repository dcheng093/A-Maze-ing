# *************************************************************************** #
#                                                                             #
#                                                         :::      ::::::::   #
#    output_writer.py                                   :+:      :+:    :+:   #
#                                                     +:+ +:+         +:+     #
#    By: dcheng <dcheng@student.42kl.edu.my>        +#+  +:+       +#+        #
#                                                 +#+#+#+#+#+   +#+           #
#    Created: 2026/04/28 12:22:01 by dcheng            #+#    #+#             #
#    Updated: 2026/04/28 12:22:01 by dcheng           ###   ########.fr       #
#                                                                             #
# *************************************************************************** #


def write_maze(
        filename: str,
        grid: list[list[int]],
        entry: tuple[int, int],
        exit: tuple[int, int],
        path: str,
        ) -> None:
    """
    write a maze to a file using hexadecimal wall encoding

    args:
        filename: output file path
        grid: maze grid represented as wall bitmasks
        entry: maze entry coordinate
        exit: maze exit coordinate
        path: solution path represented as directions
    """

    try:
        with open(filename, "w", encoding="utf-8") as f:
            # grid
            for row in grid:
                line = "".join(format(cell, "x") for cell in row)
                f.write(line + "\n")
            f.write("\n")

            # entry / exit
            f.write(f"{entry[0]},{entry[1]}             (x,y)\n")
            f.write(f"{exit[0]},{exit[1]}             (x,y)\n")

            # path
            f.write(path + "\n")

    except Exception as e:
        raise RuntimeError(f"Failed to write maze file: {e}") from e
