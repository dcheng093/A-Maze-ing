# *************************************************************************** #
#                                                                             #
#                                                         :::      ::::::::   #
#    renderer.py                                        :+:      :+:    :+:   #
#                                                     +:+ +:+         +:+     #
#    By: dcheng <dcheng@student.42kl.edu.my>        +#+  +:+       +#+        #
#                                                 +#+#+#+#+#+   +#+           #
#    Created: 2026/04/28 12:22:22 by dcheng            #+#    #+#             #
#    Updated: 2026/04/28 12:22:22 by dcheng           ###   ########.fr       #
#                                                                             #
# *************************************************************************** #

from typing import Optional
COLORS = [
    "\033[0m",   # white
    "\033[94m",  # blue
    "\033[92m",  # green
    "\033[91m",  # red
    "\033[33m",  # yellow
]
N, E, S, W = 1, 2, 4, 8
OPPOSITE = {N: S, S: N, E: W, W: E}
FOUR_TWO_PATTERN = [
    # 4
    (0, 0), (0, 1), (0, 2),
    (1, 2),
    (2, 0), (2, 1), (2, 2), (2, 3),
    (2, 4),

    # 2
    (4, 0), (5, 0), (6, 0),
    (6, 1),
    (5, 2),
    (4, 3),
    (4, 4), (5, 4), (6, 4),
]


def get_42_cells(grid: list[list[int]]) -> set[tuple[int, int]]:
    """calculates the cells occupied by the 42 logo"""
    height = len(grid)
    width = len(grid[0])

    cx = width // 2 - 3
    cy = height // 2 - 2

    cells = set()

    for dx, dy in FOUR_TWO_PATTERN:
        x, y = cx + dx, cy + dy
        if 0 <= x < width and 0 <= y < height:
            cells.add((x, y))

    return cells


def lock_42_walls(grid: list[list[int]], cells: set[tuple[int, int]]) -> None:
    """close all walls around cells belonging to the 42 pattern"""
    for x, y in cells:
        grid[y][x] = N | E | S | W


def render_ascii(
                grid: list[list[int]],
                path_coords: Optional[list[tuple[int, int]]] = None,
                color_mode: int = 0,
                player: Optional[tuple[int, int]] = None,
                special: Optional[set[tuple[int, int]]] = None,
                exit_pos: Optional[tuple[int, int]] = None
                ) -> None:
    """
    renders maze using ascii characters

    args:
    grid: maze grid represented using wall bitmasks
    path_coords: optional coordinates of the solution path
    color_mode: color index used for wall rendering
    player: optional player coordinate
    special: optional set of special cells such as the 42 logo
    exit_pos: optional exit coordinate
    """
    height = len(grid)
    width = len(grid[0])
    color = COLORS[color_mode]
    reset = "\033[0m"
    path_set = set(path_coords) if path_coords else set()
    print(color + "+" + "---+" * width + reset)

    for y in range(height):
        line1 = "|"
        line2 = "+"

        for x in range(width):
            is_42 = special and (x, y) in special
            if player == (x, y):
                line1 += f"{COLORS[2]} P {reset}"
            elif exit_pos == (x, y):
                line1 += f"{COLORS[3]} X {reset}"
            elif is_42:
                line1 += f"{COLORS[3]}███{reset}"
            elif (x, y) in path_set:
                line1 += f"{COLORS[4]} . {reset}"
            else:
                line1 += "   "
            cell = grid[y][x]

            if cell & E:
                line1 += f"{color}|{reset}"
            else:
                line1 += " "

            if cell & S:
                line2 += f"{color}---+{reset}"
            else:
                line2 += f"{color}   +{reset}"

        print(color + line1)
        print(color + line2)
